#include <graphics.h>
#include<bits/stdc++.h>
#include<conio.h>
using namespace std;
//function to find min
int min(int a, int b)
{
	int res = a;
	if(b < a)
		res = b;
	return res;
}
//function to find longest common subsequence
//we will find a sequence of 4 or 8 zeroes
int LCS(int pattern1[], int pattern2[], int n, int m)
{
    int index=-1;
	int dp[n + 1][m + 1];
	for (int i = 0; i <= n; i++)
		for (int j = 0; j <= m; j++)
			dp[i][j] = 0;
	for (int i = n - 1; i >= 0; i--)
	{
		for (int j = m - 1; j >= 0; j--)
		{
			if (pattern1[i] == pattern2[j])
            {
				dp[i][j] = dp[i + 1][j + 1] + 1;
				if(dp[i][j]==m)
                   index=i;
            }
		}
	}
	return index;
}
// function to find four consecutive zeroes
void fourbitszero(int* s,int size,int* x)
{
    for(int i=0;i<10;i++)
        x[i]=-1;
    int start=0,count=0,i=0,j=0;
    while(i<size)
    {
       while(i<size&&s[i]==1)
       {
          i++;
       }
      start=i;
       while(i<size&&s[i]==0&&count<4)
       {
          count++;
           i++;
       }
      if(count==4)
       {
          count=0;
          x[j]=start;
            j++;
       }
       else
        count=0;

    }
}
// function to find 8 consecutive zeroes
void eightbitszero(int* s,int size,int* x)
{
    for(int i=0;i<3;i++)
        x[i]=-1;
    int start=0,count=0,i=0,j=0;
    while(i<size)
    {
       while(i<size&&s[i]==1)
       {
          i++;
       }
      start=i;
       while(i<size&&s[i]==0&&count<8)
       {
          count++;
           i++;
       }
      if(count==8)
       {
          count=0;
          x[j]=start;
            j++;
       }
       else
        count=0;
    }
}

int* generate_comp_rand(int n)
{

    int* s=new int[n];
   srand(time(0));
   for(int i=0;i<n;i++ )
   s[i]=rand()%2;
	return s;
}


void NRZ_L(int *s,int size){
   int bit=29;//30
   for(int m=0;m<size;++m){
    settextstyle(1,0,1);
    if(s[m]==1)
    outtextxy(bit,50,"1");
    else  outtextxy(bit,50,"0");
    bit+=39;//40
   }
    for(int i=0,x=10;i<size;++i){
        if(s[i]==1){
            if(i!=0&&s[i]!=s[i-1])
line(x,100,x,75);
int y=x+40;
line(x,75,y,75);
x=y;
if(i==size-1||s[i]!=s[i+1])
line(x,75,x,100);
    }
    else{
        if(i!=0&&s[i]!=s[i-1])
        line(x,100,x,125);
        int y=x+40;
        line(x,125,y,125);
        x=y;
        if(i==size-1||s[i]!=s[i+1])
        line(x,125,x,100);
    }
}
settextstyle(10,0,4);
outtextxy(50,230,"--NRZ-L ENCODING---");
}

void NRZ_I(int *s,int size){

    int bit=29;//30
   for(int m=0;m<size;++m){
    settextstyle(1,0,1);
    if(s[m]==1)
    outtextxy(bit,50,"1");
    else  outtextxy(bit,50,"0");
    bit+=39;//40
   }
int previous=75,y;
for(int i=0,x=10;i<size;i++){
if(s[i]==0){
    y=previous;
    line(x,y,x+40,y);
    x=x+40;
}
else if(s[i]==1){
    
if(previous==75)
y=125;
else y=75;
line(x,previous,x,y);
line(x,y,x+40,y);
x=x+40;
previous=y;
}
}
settextstyle(10,0,4);
outtextxy(50,230,"---NRZ-I ENCODING---");
}

void Manchester(int *s,int size){
    int bit=29;//30
   for(int m=0;m<size;++m){
    settextstyle(1,0,1);
    if(s[m]==1)
    outtextxy(bit,50,"1");
    else  outtextxy(bit,50,"0");
    bit+=39;//40
   }
    setcolor(8);
    for(int i=0,x=50;i<size-1;i++,x=x+40){
        line(x,175,x,15);
    }
    setcolor(WHITE);
    for(int i=0,x=10;i<size;++i){
 if(s[i]==0){
    if(i!=0&&s[i]==s[i-1])
    line(x,125,x,75);
    line(x,75,x+20,75);
    x=x+20;
    line(x,75,x,125);
    line(x,125,x+20,125);
    x=x+20;

 }
 if(s[i]==1){
    if(i!=0&&s[i]==s[i-1])
    line(x,75,x,125);
    line(x,125,x+20,125);
    x=x+20;
    line(x,125,x,75);
    line(x,75,x+20,75);
    x=x+20;

 }
    }
   settextstyle(10,0,4);
outtextxy(50,230,"---MANCHESTER ENCODING---"); 
}

void D_Manchester(int *s,int size){
    int bit=29;//30
   for(int m=0;m<size;++m){
    settextstyle(1,0,1);
    if(s[m]==1)
    outtextxy(bit,50,"1");
    else  outtextxy(bit,50,"0");
    bit+=39;//40
   }
    int previous=75;
    setcolor(8);
    for(int i=0,x=50;i<size-1;i++,x=x+40){
        line(x,175,x,15);
    }
    setcolor(WHITE);
    for(int i=0,x=10;i<size;++i){
 if(s[i]==0){
    int y;
    if(previous==75)
     y=125;
    else y=75;
    line(x,previous,x,y);//for vertical line
    previous=y;
    line(x,y,x+20,y);//for horizontal
    x=x+20;
    if(previous==75)
     y=125;
    else y=75;
    line(x,previous,x,y);//returning vertical line
    previous=y;
    line(x,y,x+20,y);//horizontal
    x=x+20;

 }
 if(s[i]==1){
   line(x,previous,x+20,previous); 
   x=x+20;
    int y;
    if(previous==75)
     y=125;
    else y=75;
    line(x,previous,x,y);
    previous=y;
    line(x,y,x+20,y);
    x=x+20;

    }
    }
    settextstyle(10,0,4);
outtextxy(50,230,"---DIFFERENTIAL MANHESTER ENCODING---");
}
void AMI(int *s,int size){
    int bit=29;//30
   for(int m=0;m<size;++m){
    settextstyle(1,0,1);
    if(s[m]==1)
    outtextxy(bit,50,"1");
    else  outtextxy(bit,50,"0");
    bit+=39;//40
   }
    setcolor(BLUE);
    int previous=125;
    for(int i=0,x=10;i<size;i++){
       if(s[i]==0) {
        if(i!=0&&s[i-1]==1){
        line(x,previous,x,100);
        }
        line(x,100,x+40,100);
        x=x+40;
       }
       else if(s[i]==1){
        int y;
        if (previous==75)
         y=125;
        else y=75;
        if(i!=0&&s[i-1]==0)
        line(x,100,x,y);
        else line(x,previous,x,y);
        previous=y;
        line(x,y,x+40,y);
        x=x+40;

       }
    }
    settextstyle(10,0,4);
outtextxy(50,230,"---AMI ENCODING---");
}

void B8ZS(int* s,int size,int* en,int size1)
{
 int gd = DETECT, gm;
	int x=10;
	int i=0;
	int y=100;
	int m=18;
	initgraph(&gd, &gm,"C:\\TC\\BGI");

	for(i=0;i<size1;i++,x=x+20)
	{
	  line(10, 100, 610, 100);
	line(10, 50, 10, 150);


	    if(en[i]==-1)
            continue;
        if(en[i]==1)
        {
            line(x,y,x,y-20);
            line(x,y-20,x+20,y-20);
            line(x+20,y-20,x+20,y);
        }
        else{
             line(x,y,x,y+20);
            line(x,y+20,x+20,y+20);
            line(x+20,y+20,x+20,y);
        }
	}
for(int j=0;j<size;j++,m=m+20)
     {
         if(s[j])
         {
        settextjustify(CENTER_TEXT, CENTER_TEXT);
        outtextxy(m,60,"1");
         }
         else
         {
       settextjustify(CENTER_TEXT, CENTER_TEXT);
        outtextxy(m,60,"0");
         }
     }
        settextjustify(CENTER_TEXT, CENTER_TEXT);
        outtextxy(getmaxx()/2,180,"OUTPUT PLOT");
        settextjustify(CENTER_TEXT, CENTER_TEXT);
        outtextxy(getmaxx()/2,getmaxy()-100,"AMI ENCODING ALONG WITH B8ZS SCRAMBLING");
        settextjustify(CENTER_TEXT, CENTER_TEXT);
        outtextxy(getmaxx()/2,getmaxy()-20,"* PRESS ANY KEY TO CONTINUE");
	getch();
	closegraph();
}

void HDB3(int* s,int size,int* en,int size1)
{
 int gd = DETECT, gm;
	int x=10;
	int i=0;
	int y=100;
	int m=18;
	initgraph(&gd, &gm,"C:\\TC\\BGI");

	for(i=0;i<size1;i++,x=x+20)
	{
	  line(10, 100, 610, 100);
	line(10, 50, 10, 150);
	    if(en[i]==-1)
            continue;
        if(en[i]==1)
        {
            line(x,y,x,y-20);
            line(x,y-20,x+20,y-20);
            line(x+20,y-20,x+20,y);
        }
        else{
             line(x,y,x,y+20);
            line(x,y+20,x+20,y+20);
            line(x+20,y+20,x+20,y);
        }
	}
for(int j=0;j<size;j++,m=m+20)
     {
         if(s[j])
         {
        settextjustify(CENTER_TEXT, CENTER_TEXT);
        outtextxy(m,60,"1");
         }
         else
         {
       settextjustify(CENTER_TEXT, CENTER_TEXT);
        outtextxy(m,60,"0");
         }
     }
                 settextjustify(CENTER_TEXT, CENTER_TEXT);
        outtextxy(getmaxx()/2,180,"OUTPUT PLOT");
           settextjustify(CENTER_TEXT, CENTER_TEXT);
        outtextxy(getmaxx()/2,getmaxy()-100,"AMI ENCODING WITH HDB3 SCRAMBLING");
         settextjustify(CENTER_TEXT, CENTER_TEXT);
        outtextxy(getmaxx()/2,getmaxy()-20,"* PRESS ANY KEY TO CONTINUE");
	getch();
	closegraph();
}
int main(){
    int input;
    int *s;int size;
    string str;
    int gDrive = DETECT; //also numeric value 0:(autodetect)
    //*graphdriver is an integer that specifies the graphics driver to be used.

    int gMode;
    //*graphmode is an integer that specifies the initial graphics mode 
    //(unless *graphdriver equals DETECT; in which case, 
    //*graphmode is set by initgraph to the highest resolution available for the detected driver).

  initgraph(&gDrive, &gMode, NULL);
//     //initgraph initializes the graphics system by loading a graphics driver from disk
//     //and puts the system into graphics mode
cout<<"------------------ WELCOME TO LINE ENCODING PROJECT ---------------------\n";
	cout<<"Enter your choice for data generation."<<endl;
	cout<<"\n";
	cout<<"1- Random with some specific subsequences\n";
	cout<<"\n";
	cout<<"2- Complete Random \n";
    cin>>input;

    switch(input){
        case 1:{
        cout<<"Enter your pattern\n";
			cin>>str;
        	int n1=1+rand()%4;
            int n2=1+rand()%4;
       	    int * x=generate_comp_rand(n1);
       	    int * y=generate_comp_rand(n2);
       	    size=n1+str.length()+n2;
       	    s=new int[size];
       	    for(int i=0;i<size;i++)
       	    {
       	    	if(i<n1)
       	         s[i]=x[i];
					else if(i<n1+str.length())
					s[i]=str[i-n1]-'0';
					else
					s[i]=y[i-n1-str.length()];
			}
			cout<<endl;
            break;
        }

case 2:
{
     size=(rand()%(15-2+1))+2;//to generate random size between 2 t0 15;
    s=generate_comp_rand(size);
    break;

}
     }

//to choose particular decoding scheme
cout<<"FOLLOWING IS OUR INPUT:"<<endl;
			for(int i=0;i<size;i++)
			cout<<s[i];
			cout<<endl;
	cout<<"\n";
	cout<<"Enter type of encoding for the input\n";
	cout<<"\n";
	cout<<"1- NRZ-L\n";
	cout<<"\n";
	cout<<"2- NRZ-I\n";
	cout<<"\n";
	cout<<"3- Manchester\n";
	cout<<"\n";
	cout<<"4- Differential Manchester\n";
	cout<<"\n";
	cout<<"5- AMI\n";
	cout<<"\n";
    int encoding,scrambling,stype;
	cin>>encoding;
		
	
   line(10,200,10,5);
    line(10,100,610,100);
   switch(encoding)
    {
         
    case 1:
        {
           NRZ_L(s,size);
           break;
        }
        case 2:{
            NRZ_I(s,size);
            break;
        }
        case 3:
        {
            Manchester(s,size);
            break;
        }
        case 4:{
       D_Manchester(s,size);
       break;
        }
        case 5:
        {
           cout<<"Do you want scrambling\n";
		cout<<endl;
		cout<<"1- Yes"<<endl;
		cout<<endl;
		cout<<"2- No"<<endl;
		cout<<endl;
    
		cin>>scrambling;
		if(scrambling==1)
        {
            cout<<"choose scrambling"<<endl;
            cout<<"1- B8ZS"<<endl;
            cout<<"2- HDB3"<<endl;
            cin>>stype;
            int *en;
            if(stype==1)
                {
                  
                    int *x;
                    x=new int[3];

                    eightbitszero(s,size,x);
                    int flag=1;
                    en=new int[size];
                    for(int i=0;i<size;i++)
                      {
                        if(s[i])
                        {
                         en[i]=flag;
                         flag=!flag;
                       }
                      else
                      {
                       en[i]=-1;
                       }
                      }
                    for(int i=0;i<3;i++)
                    {
                      if(x[i]==-1)
                       break;
                      else
                      {
                          int v=x[i];
                          while(v>=0&&en[v]==-1)
                            v--;
                            int flag1;
                            if(v==-1)
                                flag1=1;
                            else
                          flag1=en[v];
                          v=x[i];
                          v+=3;
                          en[v]=flag1;
                          v++;
                          en[v]=!flag1;
                          flag1=!flag1;
                          v++;
                          v++;
                          en[v]=flag1;
                          v++;
                          en[v]=!flag1;
                          flag1=!flag1;
                      }
                    }
                     cout<<endl<<"SCRAMBLED DATA IS:"<<endl;
                     for(int i=0;i<size;i++)
                     {
                         if(en[i]==-1)
                            cout<<0;
                         else
                            cout<<1;
                     }
                     cout<<endl;
                        B8ZS(s,size,en,size);
                }
                       else if(stype==2)
                {
                    int *x;
                    x=new int[10];
                    fourbitszero(s,size,x);

                    int flag=1;
                    en=new int[size];
                    for(int i=0;i<size;i++)
                      {
                        if(s[i])
                        {
                         en[i]=flag;
                         flag=!flag;
                       }
                      else
                      {
                       en[i]=-1;
                       }
                      }
                      cout<<endl;

                      for(int i=0;i<10;i++)
                    {
                      if(x[i]==-1)
                       break;
                      else
                      {
                          int v=-1,u=x[i];
                          int parity=0;
                          u--;
                          while(u>=0)
                            {
                               if(v==-1&&en[u]!=-1)
                               {
                                v=u;
                                parity++;
                               }
                               else if(en[u]!=-1)
                                parity++;
                               u--;
                            }
                            parity=parity%2;
                            int flag1;
                            if(v==-1)
                                flag1=1;
                            else
                            flag1=en[v];
                          v=x[i];

                          if(parity)
                          {
                              v+=3;
                              en[v]=flag1;
                          }
                          else
                          {
                              if(v==0)
                              {
                                  en[v]=1;
                                v+=3;
                                en[v]=1;
                              }
                              else
                              {
                              en[v]=!flag1;
                              flag1=!flag1;
                              v+=3;
                              en[v]=flag1;
                              flag1=!flag1;
                              }
                            for(int p=v+1;p<size;p++)
                            {
                                if(en[p]!=-1)
                                {
                                    en[p]=!en[p];
                                }
                            }
                          }
                      }
                    }
                     cout<<endl<<"SCRAMBLED DATA IS:"<<endl;
                     for(int i=0;i<size;i++)
                     {
                         if(en[i]==-1)
                            cout<<0;
                         else
                            cout<<1;
                     }
                     cout<<endl;
                   HDB3(s,size,en,size);
                }

           
            
        }
        else AMI(s,size);
            break;
        }
    }
	
   
  
    getch();
    closegraph();
}